# kaggle-Solution
This respository contains my code for competition in kaggle.

- Santander Product Recommendation : [https://www.kaggle.com/c/santander-product-recommendation](https://www.kaggle.com/c/santander-product-recommendation)
- Allstate Claims Severity : [https://www.kaggle.com/c/allstate-claims-severity](https://www.kaggle.com/c/allstate-claims-severity)

### Kaggle Top Solutions
- Kaggle Past Solutions : [http://ndres.me/kaggle-past-solutions/](http://ndres.me/kaggle-past-solutions/)
- Kaggle优胜者代码汇总： [http://suanfazu.com/t/kaggle/230](http://suanfazu.com/t/kaggle/230)